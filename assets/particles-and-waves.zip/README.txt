A Pen created at CodePen.io. You can find this one at https://codepen.io/clockmaker/pen/wMELjr.

 This motion graphics is based on the top page of https://ics.media/
Love CreateJS .